#include "ace/OS_NS_devctl.h"

#ifndef ACE_HAS_INLINED_OSCALLS
# include "ace/OS_NS_devctl.inl"
#endif

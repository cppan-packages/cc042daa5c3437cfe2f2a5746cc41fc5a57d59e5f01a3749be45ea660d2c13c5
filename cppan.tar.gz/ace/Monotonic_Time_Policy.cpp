#include "ace/Monotonic_Time_Policy.h"

#if !defined(__ACE_INLINE__)
# include "ace/Monotonic_Time_Policy.inl"
#endif /* __ACE_INLINE__ */
